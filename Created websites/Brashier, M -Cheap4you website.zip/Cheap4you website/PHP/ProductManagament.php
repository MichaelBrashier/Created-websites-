<title>Products</title>

    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>

<form action="login.php" method="post">

<h2>Product Management form</h2>

<?php if (isset($_GET['error'])) { ?>

<p class="error"><?php echo $_GET['error']; ?></p>

 <?php } ?>

 <label>Item name</label>

<input type="text" name="Item name" placeholder="Name"><br>

<label>Item Type </label>

 <input type="text" name="uname" placeholder="Type"><br>

 <label>Item price</label>

<input type="text" name="uname" placeholder="£00.00"><br>

<label>Item description</label>

<input type="text" name="uname" placeholder="Short description"><br>

        <button type="submit">Add</button>
        <button type="submit">Remove</button>

     </form>

</body>