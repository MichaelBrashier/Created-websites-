<title>Order</title>

    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>

<form action="login.php" method="post">

<h2>Order Form</h2>

<?php if (isset($_GET['error'])) { ?>

<p class="error"><?php echo $_GET['error']; ?></p>

 <?php } ?>

 <label>First name</label>

<input type="text" name="uname" placeholder="First Name"><br>

<label>Surename </label>

 <input type="text" name="uname" placeholder="Surename"><br>

 <label>Item Name</label>

<input type="text" name="uname" placeholder="Item"><br>

<label>Number of items</label>

<input type="text" name="uname" placeholder="0"><br>

<label>Item Name</label>

<input type="text" name="uname" placeholder="Item"><br>

<label>Number of items</label>

<input type="text" name="uname" placeholder="0"><br>

<label>Item Name</label>

<input type="text" name="uname" placeholder="Item"><br>

<label>Number of items</label>

<input type="text" name="uname" placeholder="0"><br>

<label>Card holder's name</label>

<input type="text" name="uname" placeholder="Card holder's name "><br>


<label>Card number </label>

<input type="password" name="password" placeholder="card number"><br> 

<label>Address</label>

<input type="text" name="uname" placeholder="Full address here"><br>

        

        <button type="submit">Submit</button>

     </form>

</body>