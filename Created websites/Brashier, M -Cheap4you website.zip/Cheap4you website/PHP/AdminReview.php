<?php

$info = array('James robbersion', ' Kevin Beattie', 'Peter Smith', 'Jane petersion', 'Beth Jonsion');

// Listing all the variables
list($drink, $color, $power) = $info;
echo "$drink is $color and $power makes it special.\n";