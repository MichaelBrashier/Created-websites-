<title>Edit contact us</title>

    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>

<form action="login.php" method="post">

<h2>Order Form</h2>

<?php if (isset($_GET['error'])) { ?>

<p class="error"><?php echo $_GET['error']; ?></p>

 <?php } ?>

 <label>Address</label>

<input type="text" name="uname" placeholder="Address"><br>

<label>Phone number </label>

 <input type="text" name="uname" placeholder="Phone number"><br>

 <label>Email</label>

<input type="text" name="uname" placeholder="email"><br>

<label>Google maps location URL</label>

<input type="text" name="uname" placeholder="url here"><br>
        
        <button type="submit">Submit</button>

     </form>

</body>